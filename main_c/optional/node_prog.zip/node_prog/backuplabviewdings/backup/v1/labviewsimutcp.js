//Dieses Programm simuliert die TCP Verbindung von Labview.
//Labview verbindet sich ja eigentlich nur ueber TCP und sendet ein Bytearray.
//Geht ja mit nodejs 1:1

//TCP SERVER UM DATEN VON LABVIEW ZU ERHALTEN
var net = require('net');

var client = new net.Socket();
client.connect(1337, 'localhost', function() {
		console.log('Connected');
		//client.setNoDelay(true);
	//	setInterval(function(){
	//		client.write(create_arr()); }, 100);
});

client.on('data', function(message) {
		console.log("nodejsserver anfrage: " + message);
		var inputstring;
		try {
			inputstring=JSON.parse(message.utf8Data);
		} catch (e){
			console.log("error",e);
			inputstring.modus="error";
		}

		//client.destroy(); // kill client after server's response
		if(inputstring.modus == "data") // nodejs server will daten von labview
		{
			client.write(create_arr()); 
		}
		else if(inputstring.modus == "sampleanzahl"){
			//eventuell koennte ich eine bestaetigung senden.
			sampleanzahl_global = 5000;
		}
});

client.on('close', function() {
		console.log('Connection closed');
});

//globale variablen
sampleanzahl_global = 5000;

function create_arr(){
        var zahlen=sampleanzahl_global;
        var arr=new Float64Array(zahlen);//change 1.a fuer double float
        var j;
        for(var i=0 ; i<zahlen ; i++){
                 arr[i]=(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
   }
                return Buffer.from(arr.buffer);
}

