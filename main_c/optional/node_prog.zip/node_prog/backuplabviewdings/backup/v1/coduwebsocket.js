var express = require('express');
var app = express();
var http = require('http').Server(app);
//eval(require('fs').readFileSync('./ieee754.js', 'utf8'));//obsolet, wird nicht mehr verwendet

app.use(express.static(__dirname)); // app.use(express.static(__dirname + '/static'));
app.get('/', function(req, res) {
   res.sendFile(__dirname + '/livechart3.html');
//   res.sendfile(__dirname + '/index3.html');
});

var updatezeit_global=200;//in ms
var sampleanzahl_global=5000;
var count = 0;
var clients = {};

var WebSocketServer = require('websocket').server;
wsServer = new WebSocketServer({
    httpServer:http
});
wsServer.binaryType = 'arraybuffer';
//wsServer.binaryType = 'blob';

wsServer.on('request', function(request) {
   console.log('request');
   var connection = request.accept('arraybuffer', request.origin);
   //var connection = request.accept('blob', request.origin);
   // Specific id for this client & increment count
   var id = count++;
   // Store the connection method so we can loop through & contact all clients
   clients[id] = connection;

   console.log((new Date()) + ' Connection accepted [' + id + ']');

//1. allen neuen clients die aktuellen samplingzahlen zukommen lassen:
    connection.send('{"modus":"sampleanzahl", "value":'+sampleanzahl_global+'}');
    //connection.send('{"modus":"updatezeit", "value":'+updatezeit_global+'}');

//old recursive mode: now client control
//      test(clients);
//      test2(clients);
        //client: ack
        //connection.on('message',function(message) {
//              test2(clients);
//      });

        connection.on('close', function(reasonCode, description) {
                delete clients[id];
                console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' disconnected.');
        });

        connection.on('message', function(message) {
                console.log('message erhalten, msg='+message.utf8Data);
                var inputstring;
                try {
                        inputstring=JSON.parse(message.utf8Data);
                } catch (e){
                        console.log("error:",e);
                        inputstring.modus="error";
                }

                //console.log(inputstring);
                console.log("modus:"+inputstring.modus+"\nWert:"+inputstring.value);
    //var msgString = new Uint8Array(12);
                if(inputstring.modus=="sampleanzahl"){
                        sampleanzahl_global=inputstring.value;
                        gloarr[0]=create_arr();
                        gloarr[1]=create_arr();
			for(var i in tcpclients){
				tcpclients[i].write(message);
			}
                }
                else if(inputstring.modus=="updatezeit"){
                        updatezeit_global=inputstring.value;
                }
                else if(inputstring.modus=="data") {
                        //hier nun funktion zum datensenden nicht mehr rekursiv aufrufen!
                        var tx=new Date().getTime();
                        //sendDataMessage(clients);
			requestTcpData(message)
                        console.log(new Date().getTime() - tx);
                }

                if(inputstring.modus!="error"){
                        //alle clients ueber updates benachrichtigen
                        for(var i in clients){
                                clients[i].send('{"modus":"'+inputstring.modus+'", "value":'+inputstring.value+'}');
                        }
                }

        });
});

app.use("/", express.static(__dirname + '/'));//zweites slash gibt pfad an

http.listen(1338, function() {
   console.log('listening on *:1338\nType in Browser http://128.130.76.25:1338/');
});


function create_arr(){
        var zahlen=sampleanzahl_global;
        var arr=new Float64Array(zahlen);//change 1.a fuer double float
        var j;
        for(var i=0 ; i<zahlen ; i++){
                 arr[i]=(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
   }
                return Buffer.from(arr.buffer);
}

/*
function create_arr(){
        var zahlen=sampleanzahl_global;
        var mbuf = Buffer.alloc(zahlen*8);
        var arr=[];
        var j;
        for(var i=0 ; i<zahlen ; i++){
                //arr=toIEEE754Double(Math.round(100*Math.random())/100);
                arr=toIEEE754Double(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
                for(j=0 ; j<8; j++)
                        mbuf[j+i*8]=arr[j];
   }
        console.log(mbuf);
   return mbuf;
}
*/

var gloarr=[];
var kvar = 0;
gloarr[0]=create_arr();
gloarr[1]=create_arr();
console.log(gloarr[0].length);
function test2(connection){
        for(var i in connection) {
                connection[i].sendBytes(gloarr[kvar == 1 ? kvar=0 : kvar=1]);
        }
}

function test3(connection){
        console.log("sended data");-
   setTimeout(function() {
      for(var i in connection) {
         connection[i].sendBytes(create_arr());
         test3(connection);
   }},updatezeit_global);
}

function test(connection){
        console.log("sended data");-
   setTimeout(function() {
      for(var i in connection) {
         connection[i].sendBytes(gloarr[kvar == 1 ? kvar=0 : kvar=1]);
         test(connection);
   }},updatezeit_global);
}

function sendDataMessage(connection){
        console.log("sended data");
        (kvar == 1 ? kvar=0 : kvar=1);
        for(var i in connection) {
                connection[i].send(gloarr[kvar]);
                //connection[i].send('{"modus":"dataarr","value":['+gloarr[kvar]+']}');

                //connection[i].send(gloarr[kvar]);
        }
}

//Diese Funktion wird aufgerufen, wenn ein javascript client eine datenanfrage an nodejs sendet. Nodejs sendet wiederrum eine datenanfrage an labview (bzw. eben
//die TCP Verbindung und die TCP Verbindung sendet die daten danach an nodejs
//welches die daten nun an die javascript clients sendet.
 //weiss noch nicht, ob es geschindigkeitsprobleme gibt bzw. ob es stark die
 //mindestsendedauer beeinflusst. eine alternative waere ansonsten eine dauer
 //tcp verbindung, welche dauernd daten an nodejs sendet, womit nodejs damit
 //staendig die aktuellsten daten zur verfuegung stehen.
function requestTcpData(data){
	//die (eigentlich der einzige) verbundene tcp client muss benachrichtigt
	//werden.
	for(var i in tcpclients){
		tcpclients[i].write(data);
	}
}

/*
 * todo
 * moechte 5000 Zahlen pro Blob senden
 * Eine Zahl ist z.B. ein 8 Byte Double Array.
 * Demnach ist Blob ein Array, welches 5000*8=40000 Bytes Gross ist
 * also 40kByte. Will ich dies alle 20ms senden, so benoetige ich
 * 40kByte*50 =2000kByte = 2MByte / s
 * um die Datenrate zu reduzieren werde ich noch eine Kompression vornehmen,
 * z.b. GZIP
 *
 * */


//TCP SERVER UM DATEN VON LABVIEW ZU ERHALTEN
//achtung, anmerkung zur funktionsweise von tcp.
//auf einer homepage fand ich folgende beschreibung:
//That's just how TCP works. TCP is a stream of bytes. There are no packets with boundaries (or even requests) on application layer. A write call for n-bytes on one end of the connection could lead up to n 1-byte read calls on the other end. You have to be prepared that each read yields an arbitrary amount of bytes (up to the buffer size given to the read call - however as you get data pushed in node.js you can't influence that). If you need packets on application level you need to handle th at yourself, e.g. by writing length-prefixed packets to the stream.
//Faszit: Es ist nicht sicher, dass TCP die Daten als ganzen Block sendet, man muss also wissen wie lange die Daten sind, die man erwartet und solange die data events pruefen, bis alle daten da sind.

var rectcpdata = Buffer.alloc(0);

var net = require('net');
var tcpclients=[];
var tcpcount=0;

//Was man hier wissen muss, ist dass (voellig anders als bei websocket) durch den unter diesem kommentar folgenden befehl jeder verbundene client diesen code
//durchlaeuft. daher gibt es das "connection" event hier nicht!
var server = net.createServer(function(socket) {
	console.info("tcp socket connected");
	var id=tcpcount;
	tcpclients[id]=socket;
	tcpcount++;
	//socket.write('Echo server\r\n');
	//server.once("connect", socket.setNoDelay);
	//socket.pipe(socket);//liest daten und schickt sie zurueck, besser deaktivieren

	socket.on('error', function(err) {
   		console.log(err)
	});

	socket.on('close', function() {
		delete tcpclients[id];
		console.info('tcp Socket closed');
	});

	socket.on('data', function(data){
		//ich muss die events solange abfangen, bis ich alle daten
		//habe, wie lange sie sein muessen wess ich, da ich die
		//anzahl der double / float daten kenne, somit muss ich
		//die erhaltenen arraybuffer solange aneinanderreihen
		//bis ich die erforderliche gesamtlaenge habe.
		//console.log("von Labview empfangene Daten als string (macht 0 sinn): "+data.toString());
		  
		////ALTE KONTROLLE, aber tcp streaming probleme
		  console.log("von labview empfangen", data);
	          console.log("datenlaenge:", data.length);	
		  console.log("mergedlength:", rectcpdata.length);

		//kontrolle:
		//var arrayBuffer = new Uint8Array(data).buffer;
		//var view = new DataView(arrayBuffer );
		//gehe von double werten aus: 
		//console.log("view:",view.getFloat64(0,false));
		//ende kontrolle

		//Es koennen nun so viele "data" events auftreten, bis alle
		//daten da sind. ich kenne die anzahl der notwenidgen bytes,
		//da ich bei Double Zahlen 8 Byte pro Zahl habe, bei 5000
		//Double werten waeren dies 40000 Byte. Die empfangenen Daten
		//werden nun solange aneinandergereit, bis die 40000 Daten da
		//sind und erst wenn sie da sind, werden die Clients benachricht.
		rectcpdata = Buffer.concat([rectcpdata, data]);
		if(rectcpdata.length == sampleanzahl_global * 8)
		{
			//debug output
			console.log("merged:",rectcpdata);
			console.log("mergedlength:",rectcpdata.length);

		//NUN AN ALLE CLIENTS DIE DATEN VON LABVIEW SENDEN:
		//alle clients ueber updates benachrichtigen
                        for(var i in clients){
                                clients[i].send(rectcpdata);
			}
			rectcpdata = Buffer.alloc(0);//buffer zuruecksetzen..
		}
	});
});
server.listen(1337, '127.0.0.1');//labview ist ein client!
