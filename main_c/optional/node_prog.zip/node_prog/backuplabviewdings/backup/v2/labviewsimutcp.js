//Dieses Programm simuliert die TCP Verbindung von Labview.
//Labview verbindet sich ja eigentlich nur ueber TCP und sendet ein Bytearray.
//Geht ja mit nodejs 1:1

//globale variablen
var sampleanzahl_global = 5000;
var gloarr=[];
var k=0;//k ist array switcher, damit man arrs nd immer neu gen muss.
gloarr[0]=create_arr();
gloarr[1]=create_arr();


//TCP SERVER UM DATEN VON LABVIEW ZU ERHALTEN
var net = require('net');

var client = new net.Socket();
client.connect(1337, 'localhost', function() {
		console.log('Connected');
		//client.setNoDelay(true);
	//	setInterval(function(){
	//		client.write(create_arr()); }, 100);
});

//bedacht habe ich allerdings noch nicht, dass auch der tcp server blockweise senden kann..... (aber ws eher bei groesseren bloecken, trzd risky)
//ACKNOWLEDGES AN CLIENTS!	
	//TCPSERVER SENDET:
	//0: Daten kommen
	//1: Sampleanzahl hat sich geandert
	//2: updatezeit geandert.
	//255: error?

client.on('data', function(message) {
		console.log("nodejsserver anfrage: " + message);
		var inputstring;
		try {
			inputstring=JSON.parse(message);
		} catch (e){
			console.log("error aufgetreten:",e);
			inputstring="";
			inputstring.modus="error";
			client.write(255);
		}

		//client.destroy(); // kill client after server's response
		if(inputstring.modus=="sampleanzahl"){
			sampleanzahl_global=inputstring.value;
			gloarr[0]=create_arr();
			gloarr[1]=create_arr();
			client.write('1');
		}
		if(inputstring.modus == "data") // nodejs server will daten von labview
		{
			client.write('0');
			client.write(Buffer.from([64,156]));
			console.log(Buffer.from([64,156]));
			client.write(gloarr[k]);//Sende es im json array
			k=(k==0 ? 1 : 0);
		}
		else if(inputstring.modus=="updatezeit"){
			updatezeit_global=inputstring.value;//eig obsolet
			client.write('2');
		}
				if(inputstring.modus!="error"){
		//trat kein fehler auf: alle clients ueber updates benachrich
		//tigen
			//		client.write('{"modus":"'+inputstring.modus+'", "value":'+inputstring.value+'}');
			//kann so nicht mehr daten senden, da tcp die neigung hat die daten blockweise zu senden u. ich somit immer zuerst senden muesste wie lang die zu erwartenden daten sind, was mmn. unnoetiger overhead ist.
		}
});

client.on('close', function() {
		console.log('Connection closed');
});

function create_arr(){
        var zahlen=sampleanzahl_global;
        var arr=new Float64Array(zahlen);//change 1.a fuer double float
        var j;
        for(var i=0 ; i<zahlen ; i++){
                 arr[i]=(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
   }
                return Buffer.from(arr.buffer);
}

