//Dieses Programm simuliert die TCP Verbindung von Labview.
//Labview verbindet sich ja eigentlich nur ueber TCP und sendet ein Bytearray.
//Geht ja mit nodejs 1:1

//globale variablen
var sampleanzahl_global = 5000;
var gloarr=[];
var k=0;//k ist array switcher, damit man arrs nd immer neu gen muss.
gloarr[0]=create_arr();
gloarr[1]=create_arr();

var gloarr2 = [];
gloarr2[0]=create_arr2();
gloarr2[1]=create_arr2();


//TCP SERVER UM DATEN VON LABVIEW ZU ERHALTEN
var net = require('net');

var client = new net.Socket();
client.connect(1337, 'localhost', function() {
		console.log('Connected');
		//client.setNoDelay(true);
	//	setInterval(function(){
	//		client.write(create_arr()); }, 100);
});

//bedacht habe ich allerdings noch nicht, dass auch der tcp server blockweise senden kann..... (aber ws eher bei groesseren bloecken, trzd risky)
//ACKNOWLEDGES AN CLIENTS!	
	//TCPSERVER SENDET:
	//0: Daten kommen
	//1: Sampleanzahl hat sich geandert
	//2: updatezeit geandert.
	//255: error?

client.on('data', function(message) {
		console.log("nodejsserver anfrage: " + message);
		var inputstring;
		try {
			inputstring=JSON.parse(message);
		} catch (e){
			console.log("error aufgetreten:",e);
			inputstring="";
			inputstring.modus="error";
			client.write(255);
		}

		//client.destroy(); // kill client after server's response
		if(inputstring.modus=="sampleanzahl"){
			sampleanzahl_global=inputstring.value;
			gloarr[0]=create_arr();
			gloarr[1]=create_arr();
			client.write('1');
		}
		if(inputstring.modus == "data") // nodejs server will daten von labview
		{
			/* Muss nun inputstring.value abfangen.
			 * - Mit Modulo % Operator lassen sich einzelne Bits
			 * pruefen, anschliessend werden die Daten am besten
			 * hintereinander gesendet.
			 * - nodejs sollte die laenge nun auch wissen, da er
			 * sie ja von labview zusammenmergen muss, also
			 * sollte es sich auch inputstring.modus ansehen.
			 *
			*/
			//Annahme: Nur zwei Plots, inputstring.value ist max 3
			//moegliche zustaende:
			//b01 = d1 fuer plot 1
			//b10 = d2 fuer plot 2
			//b11 = d2 fuer plot 1 und 2
			var plot1 = inputstring.value % 2;
			var plot2 = Math.floor(inputstring.value/2) % 2;
			console.log("plot1:",plot1);
			console.log("plot2:",plot2);
			//TODO: verbessern, billig geloest:
			var datenlaenge = sampleanzahl_global * (plot1 + plot2) * 8; /// 2;//durch 2 wegen test.
			console.log(datenlaenge);
			var dlarr = [];//array fuer datenlaenge in byte
			dlarr[1] = datenlaenge & 255;
			datenlaenge = datenlaenge >> 8;
			dlarr[0] = datenlaenge & 255;
			client.write('0');//tcp client sagen, dass daten kommen
			client.write(Buffer.from([dlarr[1],dlarr[0]]));
			console.log(Buffer.from([dlarr[1],dlarr[0]]));
			client.write(gloarr[k]);//Sende es im json array
			client.write(gloarr2[k]);//Sende es im json array
			k=(k==0 ? 1 : 0);
			console.log("k=",k);
			console.log("value=",inputstring.value);
		}
		else if(inputstring.modus=="updatezeit"){
			updatezeit_global=inputstring.value;//eig obsolet
			client.write('2');
		}
				if(inputstring.modus!="error"){
		//trat kein fehler auf: alle clients ueber updates benachrich
		//tigen
			//		client.write('{"modus":"'+inputstring.modus+'", "value":'+inputstring.value+'}');
			//kann so nicht mehr daten senden, da tcp die neigung hat die daten blockweise zu senden u. ich somit immer zuerst senden muesste wie lang die zu erwartenden daten sind, was mmn. unnoetiger overhead ist.
		}
});

client.on('close', function() {
		console.log('Connection closed');
});

function create_arr(){
        var zahlen=sampleanzahl_global;
        var arr=new Float64Array(zahlen);//change 1.a fuer double float
        var j;
        for(var i=0 ; i<zahlen ; i++){
                 arr[i]=(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
   }
                return Buffer.from(arr.buffer);
}

function create_arr2(){
        var zahlen=sampleanzahl_global;
        var arr=new Float64Array(zahlen);//change 1.a fuer double float
        var j;
        for(var i=0 ; i<zahlen ; i++){
                 arr[i]=(20*Math.sinh(2*Math.PI*i*1/zahlen )+Math.random());
   }
                return Buffer.from(arr.buffer);
}

