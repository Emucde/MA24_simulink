var express = require('express');
var app = express();
var http = require('http').Server(app);
//eval(require('fs').readFileSync('./ieee754.js', 'utf8'));//obsolet, wird nicht mehr verwendet

app.use(express.static(__dirname)); // app.use(express.static(__dirname + '/static'));
app.get('/', function(req, res) {
   res.sendFile(__dirname + '/livechart3.html');
});

var updatezeit_global=200;//in ms
var sampleanzahl_global=5000;
var wscount = 0;//anzahl der websocket clients
var clients = {};

var WebSocketServer = require('websocket').server;
wsServer = new WebSocketServer({
    httpServer:http
});
wsServer.binaryType = 'arraybuffer';
//wsServer.binaryType = 'blob';

wsServer.on('request', function(request) {
   console.log('request');
   var connection = request.accept('arraybuffer', request.origin);
   //var connection = request.accept('blob', request.origin);
   // Specific id for this client & increment wscount
   var id = wscount++;
   // Store the connection method so we can loop through & contact all clients
   clients[id] = connection;

   console.log((new Date()) + ' Connection accepted [' + id + ']');

//1. allen neuen clients die aktuellen samplingzahlen zukommen lassen:
   connection.send('{"modus":"sampleanzahl", "value":'+sampleanzahl_global+'}');
//2. allen neuen clients sagen, ob labview verbunden (tcp):
   if(tcpcount > 0){//es existiert mind. ein tcp client (ok es kann auch nur max 1 geben)
	for(var i in clients){
		clients[i].send('{"modus":"labcon", "value":1}');
	}
   }
   else{//labview disconnected
	for(var i in clients){
		clients[i].send('{"modus":"labcon", "value":0}');
	}
   }
   //connection.send('{"modus":"updatezeit", "value":'+updatezeit_global+'}');

//old recursive mode: now client control
//      test(clients);
//      test2(clients);
        //client: ack
        //connection.on('message',function(message) {
//              test2(clients);
//      });

        connection.on('close', function(reasonCode, description) {
                delete clients[id];
		wscount--;//websocket client entfernen.
                console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' disconnected.');
        });

        connection.on('message', function(message) {
                console.log('message erhalten, msg='+message.utf8Data);
		//nodejs, dass die message eigentlich nur an labview
		//weitersenden soll, muss dennoch wissen, wenn der client
		//daten erhalten will, um wie viele daten es sich handelt
		//(also wie viele plots gesendet werden sollen)
		//Daher muss Nodejs den Wert von value ermitteln wenn modus
		//data ist.
		//Aktualisiert: Eigentlich ist das nicht notwendig zu wissen,
		//denn Nodejs erhaelt vom client einfach nur die info, dass
		//value = 3 ist und somit z.b. plot 1 u. plot 2 aktualisiert
		//werden sollen ==> Da ich die Datenlaenge ohnehin mitsende,
		//weiss nodejs wie viele daten es von labview erhaelt und
		//mergt die daten einfach zusammen und sendet sie an den js
		//client. der client weiss auch schon, welche plots geupdatet
		//werden muessen.
		var inputstring;
		try {
			inputstring=JSON.parse(message.utf8Data);
		} catch (e){
			console.log("error beim parsen client -> node aufgetreten:",e);
			inputstring="";
			inputstring.value=-1;
			inputstring.modus="error";
     		}
		console.log(inputstring);
		//datenlaenge nun aus daten ermitteln, wenn modus == 'data'
		if(inputstring.modus == 'data'){
			//dann datenlaenge ermitteln:
			//var plot1 = inputstring.value % 2;
			//var plot2 = Math.floor(inputstring.value/2) % 2;
			//console.log("plot1:",plot1);
			//console.log("plot2:",plot2);
			datalength = sampleanzahl_global * 8 * (getplotnumber(inputstring.value));
		}
		requestTcpData(message.utf8Data);//TODO nicht besser nur senden wenn kein error?
		//danach sendet TCP client die Daten und nodejs websocket onmessage "data" im TCPServer (unten) wird ausgefuehrt.
        });
});

app.use("/", express.static(__dirname + '/'));//zweites slash gibt pfad an

http.listen(1338, function() {
   console.log('listening on *:1338\nType in Browser http://128.130.76.25:1338/');
});

function getplotnumber(number)
{
	//number sollte nicht neg sein.
	var pn = 0;
	while(number>0)
	{
		pn += number % 2;
		number = Math.floor(number/2); 
	}
	return pn;
}

function create_arr(){
        var zahlen=sampleanzahl_global;
        var arr=new Float64Array(zahlen);//change 1.a fuer double float
        var j;
        for(var i=0 ; i<zahlen ; i++){
                 arr[i]=(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
   }
                return Buffer.from(arr.buffer);
}

/*
function create_arr(){
        var zahlen=sampleanzahl_global;
        var mbuf = Buffer.alloc(zahlen*8);
        var arr=[];
        var j;
        for(var i=0 ; i<zahlen ; i++){
                //arr=toIEEE754Double(Math.round(100*Math.random())/100);
                arr=toIEEE754Double(20*Math.sin(2*Math.PI*i*1/zahlen )+Math.random());
                for(j=0 ; j<8; j++)
                        mbuf[j+i*8]=arr[j];
   }
        console.log(mbuf);
   return mbuf;
}
*/

var gloarr=[];
var kvar = 0;
gloarr[0]=create_arr();
gloarr[1]=create_arr();
console.log(gloarr[0].length);
function test2(connection){
        for(var i in connection) {
                connection[i].sendBytes(gloarr[kvar == 1 ? kvar=0 : kvar=1]);
        }
}

function test3(connection){
        console.log("sended data");-
   setTimeout(function() {
      for(var i in connection) {
         connection[i].sendBytes(create_arr());
         test3(connection);
   }},updatezeit_global);
}

function test(connection){
        console.log("sended data");-
   setTimeout(function() {
      for(var i in connection) {
         connection[i].sendBytes(gloarr[kvar == 1 ? kvar=0 : kvar=1]);
         test(connection);
   }},updatezeit_global);
}

function sendDataMessage(connection){
        console.log("sended data");
        (kvar == 1 ? kvar=0 : kvar=1);
        for(var i in connection) {
                connection[i].send(gloarr[kvar]);
                //connection[i].send('{"modus":"dataarr","value":['+gloarr[kvar]+']}');

                //connection[i].send(gloarr[kvar]);
        }
}

//Diese Funktion wird aufgerufen, wenn ein javascript client eine datenanfrage an nodejs sendet. Nodejs sendet wiederrum eine datenanfrage an labview (bzw. eben
//die TCP Verbindung und die TCP Verbindung sendet die daten danach an nodejs
//welches die daten nun an die javascript clients sendet.
 //weiss noch nicht, ob es geschindigkeitsprobleme gibt bzw. ob es stark die
 //mindestsendedauer beeinflusst. eine alternative waere ansonsten eine dauer
 //tcp verbindung, welche dauernd daten an nodejs sendet, womit nodejs damit
 //staendig die aktuellsten daten zur verfuegung stehen.
function requestTcpData(data){
	//die (eigentlich der einzige) verbundene tcp client muss benachrichtigt
	//werden.
	for(var i in tcpclients){
		tcpclients[i].write(data);
	}
}

/*
 * todo
 * moechte 5000 Zahlen pro Blob senden
 * Eine Zahl ist z.B. ein 8 Byte Double Array.
 * Demnach ist Blob ein Array, welches 5000*8=40000 Bytes Gross ist
 * also 40kByte. Will ich dies alle 20ms senden, so benoetige ich
 * 40kByte*50 =2000kByte = 2MByte / s
 * um die Datenrate zu reduzieren werde ich noch eine Kompression vornehmen,
 * z.b. GZIP
 *
 * */


//TCP SERVER UM DATEN VON LABVIEW ZU ERHALTEN
//achtung, anmerkung zur funktionsweise von tcp.
//auf einer homepage fand ich folgende beschreibung:
//That's just how TCP works. TCP is a stream of bytes. There are no packets with boundaries (or even requests) on application layer. A write call for n-bytes on one end of the connection could lead up to n 1-byte read calls on the other end. You have to be prepared that each read yields an arbitrary amount of bytes (up to the buffer size given to the read call - however as you get data pushed in node.js you can't influence that). If you need packets on application level you need to handle th at yourself, e.g. by writing length-prefixed packets to the stream.
//Faszit: Es ist nicht sicher, dass TCP die Daten als ganzen Block sendet, man muss also wissen wie lange die Daten sind, die man erwartet und solange die data events pruefen, bis alle daten da sind.

var rectcpdata = Buffer.alloc(0);

var net = require('net');
var tcpclients=[];
var tcpcount=0;//anzahl der tcp clients, wird bei close verringert.

var datain = 0;//diese globale variable wird dafuer verwendet um zu signalisieren ob gerade daten vom tcp client kommen oder nicht. denn kommen daten vom tcp client koennen diese in bloecken kommen u. daher muss geachtet werden, dass diese bloecke richtig gemergt werden.

var modus ='3';//3: kein modus
var start = 1;//wenn start = 1 dann wurde erstes byte gesendet.
var datalength = 0;//gibt datenlaenge an, wird durch 2. u. 3. byte gestetzt
//Was man hier wissen muss, ist dass (voellig anders als bei websocket) durch den unter diesem kommentar folgenden befehl jeder verbundene client diesen code
//durchlaeuft. daher gibt es das "connection" event hier nicht!

//TCP UPDATE: TCP hat den grossen Nachteil, dass nicht klar ist, wie gross die Datenpackete sein werden. Da ich an den Client nicht nur daten sende, sondern auch updates, ob gewisse aenderungen uebernommen, muss ich dem client irgendwie mitteilen, wie lang die messages sein koennen.
//M0: Ich sende zuerst ein Byte fuer den Modus (0, 1, 2..) und entscheide nach diesem byte, welchem modus die nachfolgenden daten zuzuordnen sind. Problem: Ich kan nicht gewaerhleisten, dass der Modus als einzelnes Byte gesendet wird, manchmal wird er einfach den Daten vorangehaengt und somit nicht erkannt. Ich koennte zwar das Byte raussschneiden u. es standardmeassig wie bei M2 im bytearray mitsenden, allerdings habe ich dann den nachteil, dass ich keine andere Daten senden kann (updates u.ae.) sondern nur modis...
//M1: ich sende Bytes und schau dass alle Messages unterschiedlich lang, aber auch immer gleich lang sind. ob ich das sicher garantieren laesst, ist fragwuerdig.
//M2: Ich sende ueber die ersten zwei Bytes die laenge der zu uebertragenden Bytes mit, d.h. eine 16bit zahl (bis 65535 Datenlaenge). Hat allerdings den Vorteil, dass meine Datenlaenge beschraenkt ist und ich auch den Fall berueckischtigen muss, wenn er alles byteweise senden wuerde.
//M3: Websocket Server direkt in Labview, dann kann ich mir den TCP Scheiss komplett sparen.
//Prinzipiell muss man sagen, dass die zusaetzlichen Datenoperationen recht wurscht sind, da es ohnehin alles local am server laeuft. Aber wenn es ohnehin local am server laeuft koennte man es vielleicht an komplett anders machen, allerdings moechte ich doch Betriebsystemunabhaengig bleiben, was TCP schon ermoeglicht.
//Wahl: M2, eventuell noch mit 3. byte um dateigroesse zu erhoehen. Ich beruecksichtige auch die faelle, dass er byteweise sendet. allerdings muss ich auch die modis irgendwie klarstellen, somit: 1. byte: modus, 2 u. 3. byte: datengroesse, restliche bytes: daten.
var server = net.createServer(function(socket) {
	//Diese Routine wird immer durchlaufen, wenn ein neuer Client
	//verbunden ist. (funktioniert etwas anders als die websocket Routine,
	//obwohl beides Server sind).
	console.info("tcp socket connected - labview verbunden");
	var id=tcpcount;
	tcpclients[id]=socket;
	tcpcount++;//neuer client dazu
	//socket.write('Echo server\r\n');
	//server.once("connect", socket.setNoDelay);
	//socket.pipe(socket);//liest daten und schickt sie zurueck, besser deaktivieren

//###### WEBSOCKET CLIENTS BENACHRICHTIEN, dass Labview via TCP verbunden #####
	for(var i in clients){
		clients[i].send('{"modus":"labcon", "value":1}');
	}
//######## end benachrichten
	socket.on('error', function(err) {
   		console.log(err)
	});

	socket.on('close', function() {
		//wenn labview den kontakt verliert. Danach muss der websocket
		//server an seine clients senden, dass labview nicht verbunden
		//ist.
		delete tcpclients[id];//das problem von delete ist, dass es id nicht verringert.
		tcpcount--;//client entfernen
		console.info('tcp Socket closed - labview disconnected!');

		//websocket clients benachrichten, dass labview disconnected
		for(var i in clients){
			clients[i].send('{"modus":"labcon", "value":0}');
		}

	});

	socket.on('data', function(data){
		//ich muss die events solange abfangen, bis ich alle daten
		//habe, wie lange sie sein muessen wess ich, da ich die
		//anzahl der double / float daten kenne, somit muss ich
		//die erhaltenen arraybuffer solange aneinanderreihen
		//bis ich die erforderliche gesamtlaenge habe.
		//console.log("von Labview empfangene Daten als string (macht 0 sinn): "+data.toString());
		  
		////ALTE KONTROLLE, aber tcp streaming probleme
		  console.log("von labview empfangen global", data);
	          console.log("datenlaenge global:", data.length);	
		  console.log("mergedlength global:", rectcpdata.length);

		//kontrolle:
		//var arrayBuffer = new Uint8Array(data).buffer;
		//var view = new DataView(arrayBuffer );
		//gehe von double werten aus: 
		//console.log("view:",view.getFloat64(0,false));
		//ende kontrolle

		//Es koennen nun so viele "data" events auftreten, bis alle
		//daten da sind. ich kenne die anzahl der notwenidgen bytes,
		//da ich bei Double Zahlen 8 Byte pro Zahl habe, bei 5000
		//Double werten waeren dies 40000 Byte. Die empfangenen Daten
		//werden nun solange aneinandergereit, bis die 40000 Daten da
		//sind und erst wenn sie da sind, werden die Clients benachricht.
		//TODO: datenlaenge nicht mehr senden, sondern gleich daten senden. dafuer muss nodejs mehr infos mitsniffen aber eh einfach
		// Problem: labview kann nodejs nicht mehr mitteilen, dass
		// es die daten auch erfolgreich uebernommen hat. Es waere
		// aber sehr gut, um pruefen zu koennen, ob die befehle auch
		// uebernommen wurden, damit es nicht zu ueberschreibungen
		// kommen kann, die merkwuerdige fehler hervorrufen.
		// 
		// ==> TODO: Ok, ich lasse es so, dass er mir ein byte senden
		// kann, in welchem er mitteilt, was der modus ist.
		
		//data.length = 1: data[0] ... modus, data.slice(1) liefert []
		//data.length > 1: data[0] ... modus, data.slice(1) liefert daten (muss nicht vollstaendig sein)
		if(start == 1){
			modus = data[0];
			data = data.slice(1);
			start = 0;
			rectcpdata = Buffer.alloc(0);
		}

		if(modus == 48 && start == 0)//daten kommen
		{
			console.log("modus data");
			datain = 1;//weitere daten werden kommen.
		}

console.log("datalength_before_datain==1= (also solldatenlaenge)",datalength);
console.log("start=",start);
console.log("modus=",modus);
console.log("modus===48", modus === 48);
console.log("rectcpdata.length=",rectcpdata.length);
console.log("datain=",datain);
		if(datain == 1)
		{
			console.log(rectcpdata.length);
			console.log(data.length);
			rectcpdata = Buffer.concat([rectcpdata, data]);
			console.log("ifdatain=1rec:",rectcpdata.length);
			console.log("datlen_1rec:",datalength);
			//if(rectcpdata.length == sampleanzahl_global * 8)//old
			if(rectcpdata.length == datalength)
			{
				//debug output
				console.log("merged:",rectcpdata);
				console.log("mergedlength:",rectcpdata.length);

		//PROBLEM: nodejs mergt daten wenn daten kommen und sendet
			//wenn fertig gemergt. soll der tcp server allerdings
			//acks senden, koennten auch andere daten kommen, also
			//muss ich abfangen, ob nur daten kommen oder auch
			//anderes.

			//NUN AN ALLE CLIENTS DIE DATEN VON LABVIEW SENDEN:
			//alle clients ueber updates benachrichtigen
                        	for(var i in clients){
                               		clients[i].send(rectcpdata);
					clients[i].send('{"modus":"data", "value":0}');//bestaetigung an websocket clients dass daten fertig.
				}
				datalength = 0;
				datain = 0;//es werden keine daten mehr kommen
				rectcpdata = Buffer.alloc(0);//buffer zuruecksetzen..
				start = 1;//wenn neue daten kommen weiss ich dass solange start = 1 ist, das erste byte kam.
			}
			console.log("rectcpdata.length_end=",rectcpdata.length);
			console.log("\n");
		}

	});
});
server.listen(1337, '127.0.0.1');//labview ist ein client!
