var net = require('net');

var server = net.createServer(function(socket) {
	socket.write('Echo server\r\n');
	socket.pipe(socket);

	socket.on('error', function(err) {
   		//console.log(err)
	});

	socket.on('connection', function(){
		console.log('client connected');
	});
	
	socket.on('close', function() {
		console.info('Socket closed');
	});

	socket.on('data', function(data){
		console.log("von Labview empfangene Daten als string (macht 0 sinn): "+data.toString());
		console.log(data);
		
		//kontrolle:
		var arrayBuffer = new Uint8Array(data).buffer;
		var view = new DataView(arrayBuffer );
		//gehe von double werten aus: 
		console.log("view:",view.getFloat64(0,false));
		//ende kontrolle

	});
});

server.listen(1337, '127.0.0.1');
